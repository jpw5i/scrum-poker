<?php

namespace src\api\exceptions;

class ForbiddenException extends \Exception
{

}