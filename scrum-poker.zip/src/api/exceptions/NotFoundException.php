<?php

namespace src\api\exceptions;

class NotFoundException extends \Exception
{

}