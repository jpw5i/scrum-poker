# scrum poker

[![Deploy website](https://github.com/73h/scrum-poker/actions/workflows/main.yml/badge.svg?branch=main)](https://github.com/73h/scrum-poker/actions/workflows/main.yml)

Online Scrum Poker

a zero dependencies project, because it's fun :)

https://poker.3doo.de/
